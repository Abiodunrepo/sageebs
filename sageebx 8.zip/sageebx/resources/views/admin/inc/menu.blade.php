<div class="graphs-2 ">
	     <div class="xs">
  	   
  	        



        <div class="col-md-12 inbox_right">
            <div style="margin-bottom:10px;" class="mailbox-content">
            <h4>Ship Arrival/Departure</h4>
            </div>
         	<form action="#" method="GET">
                <div class="input-group">
                    <input type="text" name="search" class="form-control1 input-search" placeholder="Vessel Name...">
                    <span class="input-group-btn">
                        <button class="btn btn-success" type="button"><i class="fa fa-search"></i></button>
                    </span>
                </div><!-- Input Group -->
            </form>
            <div class="mailbox-content">
               
                <table class="table">
                    <tbody>
                      <tr class="unread checked">
                        <td class="">
                            Vessel Name :
                        </td>
                        
                        
                        <td>
                            
                        </td>
                        
                       
                    </tr>
                    <tr class="unread checked">
                        <td class="">
                            Lane :
                        </td>
                        
                        
                        <td>
                            
                        </td>
                        
                       
                    </tr>
                    <tr class="unread checked">
                        <td class="">
                            Status :
                        </td>
                        
                        
                        <td>
                            
                        </td>
                        
                       
                    </tr>
                        
                    </tbody>
                </table>
                
               </div>

               <div style="margin-top: 10px;" class="mailbox-content">
               
                  <div class="table-responsive">
                      <table class="table table-bordered">
                        <thead>
                         
                        </thead>
                        <tbody>
                          <p style="font-size: 13px;"> Full Schedule</p>
                          <tr>
                            <th scope="row">Port</th>
                            <td>Voyage #</td>
                            <td>Terminal</td>
                            <td>Arrival Time</td>
                            <td>Berthing Time</td>
                            <td>Departure Time</td>
                            
                          </tr>
                         
                        
                        </tbody>
                      </table>
                    </div><!-- /.table-responsive -->
                
               </div>

               <div style="margin-top: 10px;" class="mailbox-content">

                <p id="preview"  style="font-size: 13px;"> <i class="fa fa-arrow-down"></i>Tracking</p>
               
                <div iclass="table-responsive">
                    <table    id="div1" class="table table-bordered">
                      <thead>
                       
                      </thead>
                      <tbody>
                       
                        <tr >
                          <th scope="row">Port</th>
                          <td>B/L Number </td>
                          <td>Ship ID</td>
                          <td>Arrival Date</td>
                          <td>Cargo Status</td>
                          <td>Cargo Location</td>
                          <td>Container</td>
                          <td>No of units</td>
                          <td>Description</td>
                          <td>Release Status</td>
                          <td>Delivery Status</td>
                          <td>Transaction Code</td>
                          
                        </tr>
                       
                      
                      </tbody>
                    </table>
                  </div><!-- /.table-responsive -->
              
             </div>
            
               
            </div>
            <div class="clearfix"> </div>
       </div>


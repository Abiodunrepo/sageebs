<div class="navbar-default sidebar" role="navigation">
          <div class="sidebar-nav navbar-collapse">
          <ul style="margin-top: -32px;" class="nav menu-css" id="side-menu">
              <li>
                <a style="color: #fff;" href=""
                  ><i class="fa fa-user fa-fw nav_icon"></i>Customer Portal</a
                >
              </li>
              <li>
                <a style="color: #fff;" href="#"
                  ><i class="fa fa-laptop nav_icon"></i>Services<span
                    class="fa arrow"
                  ></span
                ></a>
                <ul class="nav nav-second-level">
                  <li style="color: #fff;">
                    <a style="color: #fff;" href="{{url('customer/Ship-Arrival-Departure')}}"
                      >Ship Arrival/Departure</a
                    >
                   
                  <a style="color: #fff;" href="{{url('customer/CargoTracking')}}"
                      >Cargo Tracking
                    </a>
                  </li>
                </ul>
                <!-- /.nav-second-level -->
              </li>
              <li>
                <a style="color: #fff;" href="#"
                  ><i class="fa fa-users nav_icon"></i>Customer Requests<span
                    class="fa arrow"
                  ></span
                ></a>
                <ul class="nav nav-second-level">
                  <li>
                    <a style="color: #fff;" href="{{url('customer/Request-VGM')}}"
                      >Request VGM (Weighbridge)</a
                    >
                    <a style="color: #fff;" href="{{url('customer/Request-Cargo-Examination')}}"
                      > Request Cargo Examination</a
                    >
                    <a style="color: #fff;" href="{{url('customer/Request-Cargo-Joint-Inspection')}}"
                      >Request Cargo Joint Inspection</a
                    >
                    <a style="color: #fff;" href="{{url('customer/Request-Cargo-Transfer')}}">Request Cargo Transfer</a>
                    <a style="color: #fff;" href="{{url('customer/Request-Cargo-Stepdown')}}"
                      > Request Cargo Stepdown</a
                    >
                  </li>
                   
  
   
   
  
                
                </ul>
                <!-- /.nav-second-level -->
              </li>
             
            </ul>
          </div>
          <!-- /.sidebar-collapse -->
        </div>
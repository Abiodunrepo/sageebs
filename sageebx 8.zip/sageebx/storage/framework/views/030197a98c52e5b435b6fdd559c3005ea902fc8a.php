<?php $__env->startSection('content'); ?>

<div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    




                    <?php echo $__env->make('customer.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Request Cargo Transfer</h3>
  	<h1>
  </h1>
   <div class="panel-body1">
   
    </div>
    
   

   
  </div>
  
   </div>
   
   
      </div>

      
              
      
       


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.customer-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/customer/Request-Cargo-Transfer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    




                    <?php echo $__env->make('admin.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 
    
     <div class="grid_3 grid_5">
     <h3><?php echo e($shipschedule->vessel_name); ?> <?php echo e($shipschedule->vessel_voyage); ?> </h3>
       <div class="but_list">
	    <div class="col-md-6 page_1">
			
              <table class="table table-bordered">
				<thead>
					<tr>
						<th width="50%">Line</th>
						<th width="50%"><?php echo e($shipschedule->vessel_line); ?></th>
					</tr>
				</thead>
				<tbody>
				<th width="50%">Status</th>
						<th width="50%"><?php echo e($shipschedule->vessel_status); ?></th>
					<tr>
					<th width="50%">Port</th>
						<th width="50%"><?php echo e($shipschedule->vessel_port); ?></th>
					</tr>
					<tr>
          <th width="50%">Terminal</th>
						<th width="50%"><?php echo e($shipschedule->vessel_terminal); ?></th>
					</tr>
					<tr>
						<th width="50%">Date</th>
						<th width="50%" ><?php echo e($shipschedule->vessel_arrival_date); ?></th>
					</tr>
					<tr>
						<th width="50%">Berthing Time</th>
						<th width="50%"><?php echo e($shipschedule->vessel_berthing_time); ?></th>
					</tr>
					<tr>
						<th width="50%">Depature Time</th>
						<th width="50%"> <?php echo e($shipschedule->vessel_departure_time); ?></th>
					</tr>
				</tbody>
			  </table>                    
		</div>
		
	   </div>
	   <div class="clearfix"> </div>
	   </div>
     </div>
   

   
  </div>
  
   </div>
   
   
      </div>

      
              
      
       


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/customer/showschedule.blade.php ENDPATH**/ ?>
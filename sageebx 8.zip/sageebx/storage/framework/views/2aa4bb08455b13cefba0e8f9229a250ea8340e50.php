
<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- CSRF Token -->
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Admin')); ?></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
      $(document).ready(function() {
    $('#div1').hide();
    $('#preview').on('click', function() {
            $('#div1').toggle(300);
    });
});

    
      </script>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta
      name=""
    />
    <style>
      .list-p {
        font-size: 20px;
        color: green;
      }
    </style>
    <script type="application/x-javascript">
      addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
    </script>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('ebs')); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('ebs')); ?>/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('ebs')); ?>/css/font-awesome.css" rel="stylesheet" />
    <!-- jQuery -->
    <script src="<?php echo e(asset('ebs')); ?>/js/jquery.min.js"></script>

    <style>
      p {
        color: black;
      }
    </style>
    <!----webfonts--->
    <link
      href="https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900"
      rel="stylesheet"
      type="text/css"
    />
    <!---//webfonts--->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('ebs')); ?>/js/bootstrap.min.js"></script>
   
  </head>
  <body>
    <div id="wrapper">
      <!-- Navigation -->

      <!-- start menu bar -->
      <nav
        class="top1 navbar navbar-default navbar-static-top"
        role="navigation"
        style="margin-bottom: 0"
      >
        <div class="navbar-header">
          <button
            type="button"
            class="navbar-toggle"
            data-toggle="collapse"
            data-target=".navbar-collapse"
          >
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand " href="<?php echo e(url('/panel')); ?>"
            ><h3>
              <span style="color: green;">EBS | ADMIN
              </span>
              
              
            </h3></a
          >
        </div>
        <!-- /.navbar-header -->
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown">
            <a
              href="#"
              class="dropdown-toggle avatar"
              data-toggle="dropdown"
            ></a>
          </li>
          <?php if(!auth()->guard('admin')->check()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('admin.register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                           
                       
           <li class="dropdown">
              <a href="#" class="dropdown-toggle avatar" data-toggle="dropdown"><?php echo e(Auth::guard('admin')->user()->name); ?><span class="badge">*</span></a>
              <ul class="dropdown-menu">
           
           
          
            
          
            <li class="m_2"><a href="{ route('admin.logout') }}" onclick="event.preventDefault();
            document.getElementById('logout-form').submit();"> <i class="fa fa-lock"></i> <?php echo e(__('Logout')); ?></a>
            
            <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form></li>  
              </ul>
            </li>
            <?php endif; ?>
        </ul>
<!-- /.end menu bar -->
       
          <!-- /.sidebar-collapse -->
        </div>
        <!-- /.navbar-static-side -->
      </nav>

      
      <?php echo $__env->yieldContent('content'); ?>
    <!-- /#wrapper -->
      <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- Nav CSS -->
    <link href="<?php echo e(asset('ebs')); ?>/css/custom.css" rel="stylesheet" />
    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('ebs')); ?>/js/metisMenu.min.js"></script>
    <script src="<?php echo e(asset('ebs')); ?>/js/custom.js"></script>
  </body>
</html>
<script>
function myFunction() {
  alert("Available on Demand!");
}
</script>

<?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/layouts/admin-custom.blade.php ENDPATH**/ ?>
<div style="  " class="graphs">
            <div   >
          <div style="  filter: blur(0px);-webkit-filter: blur(0px);"  class="grid_3 grid_4">
            <div class="bs-example">
              <div class="row">
                <div class="col-md-3">
                  <p style="  font-size: 20px;color: green;">Shipping</p>
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="#"><p style="color:black;">Vessel Logging</p></a>
                  <a href="#"><p style="color:black;">Cargo Release </p></a>
                   <a href="#"><p style="color:black;">Export Booking </p></a>
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="#"><p style="color:black;">Agency SOF/NOR Reports</p></a>
                  <a href="#"><p style="color:black;">Demmurage & Detention</p></a>
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="#"><p style="color:black;">BL/Telex Mgt.</p></a>
                  <a href="#"><p style="color:black;">Payment Refund</p></a>
                  
                </div>
              </div>
            </div>
          </div>

          <div class="grid_3 grid_4">
            <div class="bs-example">
              <div class="row">
                <div class="col-md-3">
                  <p style="  font-size: 20px;color: green;">
                    Logistics and Operations
                  </p>
                </div>

                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="https://app.zohocreator.com/sageplatform/ebs/#Form:Create_Vessel"><p style="color:black;">Vessel Planning</p></a>
                 <a href="#"><p style="color:black;">Cargo Invoicing</p></a>
                  <a href="#"><p style="color:black;">Offdock Processing</p></a>
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="#"><p style="color:black;">Manifest & Cargo Documentation</p></a>
                   <a href="#"><p style="color:black;">Yard Inventory</p></a>
                    <a href="#"><p style="color:black;">Operations Statistics</p></a>
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="#"><p style="color:black;">Discharge</p></a>
                   <a href="#"><p style="color:black;">Delivery Processing</p></a>
                   
                </div>
              </div>
            </div>
          </div>

          <div class="grid_3 grid_4">
            <div class="bs-example">
              <div class="row">
                <div class="col-md-3">
                  <p style="  font-size: 20px;color: green;">e - Commerce</p>
                </div>

                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="<?php echo e(url('/customer/Ship-Arrival-Departure')); ?>"><p style="color:black;">Customer Portal</p></a>
                    <a href="<?php echo e(url('/customer/Ship-Arrival-Departure')); ?>"><p style="color:black;">Off Dock Integrations</p></a>
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="<?php echo e(url('/customer')); ?>"><p style="color:black;">Online transactions</p></a>
                   <a href="<?php echo e(url('/customer')); ?>"><p style="color:black;">Customer Access Control</p></a>
                 
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href=""><p style="color:black;">Online Cargo Tracking</p></a>
                  
                   
                </div>
              </div>
            </div>
          </div>

          <div class="grid_3 grid_4">
            <div class="bs-example">
              <div class="row">
                <div class="col-md-3">
                  <p style="  font-size: 20px;color: green;">Finance</p>
                </div>



                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Operational Reporting</p></a>
                   <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Financial Reporting</p></a>
                  
                    <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Cash Management</p></a>
                      <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Time & Expenses</p></a>
                      <a href="<?php echo e(url('/platform')); ?>"><p style="color:black;">Platform Services</p></a>
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Company</p></a>
                   <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Accounts Receivable</p></a>
                    <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Order Entry</p></a>
                     <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Budget Planning</p></a>
                    
                </div>
                <div class="col-md-3">
                  <p></p>
                  <p></p>
                  <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">General Ledger</p></a>
                   <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Account Reconcialiation</p></a>
                   <a href="https://trial.intacct.com/ia/acct/login.phtml?.cpaassoc=&.affiliation=&.fl=1&.done=frameset.phtml"><p style="color:black;">Purchasing</p></a>
                   
                </div>
              </div>
            </div>
          </div>
        </div><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/ebs/inc/menu.blade.php ENDPATH**/ ?>
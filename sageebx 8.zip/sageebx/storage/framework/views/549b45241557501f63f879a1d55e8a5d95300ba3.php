<?php $__env->startSection('content'); ?>

<div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    




                    <?php echo $__env->make('customer.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Ship Schedule</h3>
  	
   <div class="panel-body1">
   <table class="table">
     <thead>
        <tr>
          <th>#</th>
          <th>Vessel & Voyage</th>
          <th>Arriving At</th>
          <th>Liner</th>
          
          <th>Arrival (ETA)</th>
          
          
        </tr>
      </thead>
      <tbody>
	  <?php $__currentLoopData = $shipschedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipschedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <tr>
            
        </i>
		          <th scope="row"><?php echo e($shipschedule->id); ?></th>
              <td scope="row"><?php echo e($shipschedule->vessel_name); ?> <?php echo e($shipschedule->vessel_voyage); ?></td>
		         
		          <td><?php echo e($shipschedule->vessel_terminal); ?></td>
		          <td><?php echo e($shipschedule->vessel_line); ?></td>
              
              <td><?php echo e($shipschedule->vessel_arrival_date); ?> <?php echo e($shipschedule->vessel_berthing_time); ?></td>
              
			     
		        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php echo e($shipschedules->links()); ?>

    </div>
    
   

   
  </div>
  
   </div>
   
   
      </div>

      
              
      
       


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.customer-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/customer/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    




                    <?php echo $__env->make('admin.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Ship Schedule</h3>
  	
   <div class="panel-body1">
   <table class="table">
     <thead>
        <tr>
          <th>#</th>
          <th>Vessel & Voyage</th>
          <th>Arriving At</th>
          <th>Liner</th>
          
          <th>Arrival (ETA)</th>
          <th><a href="/shipschedule/create"><i class="fa fa-plus fa-lg" aria-hidden="true"></i></a></th>
          
        </tr>
      </thead>
      <tbody>
	  <?php $__currentLoopData = $shipschedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipschedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <tr>
            
        </i>
		          <th scope="row"><?php echo e($shipschedule->id); ?></th>
              <td scope="row"><a href="/shipschedule/<?php echo e($shipschedule->id); ?>"><?php echo e($shipschedule->vessel_name); ?> <?php echo e($shipschedule->vessel_voyage); ?></a></td>
		         
		          <td><?php echo e($shipschedule->vessel_terminal); ?></td>
		          <td><?php echo e($shipschedule->vessel_line); ?></td>
              
              <td><?php echo e($shipschedule->vessel_arrival_date); ?> <?php echo e($shipschedule->vessel_berthing_time); ?></td>
              
			  <td>
        <span><a style="color:blue; margin-right:10px;" href="shipschedule/<?php echo e($shipschedule->id); ?>/edit"><i class="fa fa-pencil-square-o  fa-lg " aria-hidden="true"></i></a>
        
        <a style="color:red;"  
href="#"
    onclick="
    var result = confirm('Are you sure you wish to delete this Company?');
        if( result ){
                event.preventDefault();
                document.getElementById('delete-form').submit();
        }
            "
            >
        <i class="fa fa-times fa-lg " aria-hidden="true">
        </i>
        </a>
        <form id="delete-form" action="<?php echo e(route('shipschedule.destroy',[$shipschedule->id])); ?>" 
  method="POST" style="display: none;">
          <input type="hidden" name="_method" value="delete">
          <?php echo e(csrf_field()); ?>

</form>
        
        </span>
       
         </td>     
		        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php echo e($shipschedules->links()); ?>

    </div>
    
   

   
  </div>
  
   </div>
   
   
      </div>

      
              
      
       


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/admin/scheduledb.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    




                    <?php echo $__env->make('admin.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Admins Tables</h3>
  	
   <div class="panel-body1">
   <table class="table">
     <thead>
        <tr>
          <th>#</th>
          <th>User</th>
          <th>Email</th>
          <th>Created at</th>
         
        </tr>
      </thead>
      <tbody>
	  <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <tr>
           
		          <th scope="row"><?php echo e($admin->id); ?></th>
		          <td><?php echo e($admin->name); ?></td>
		          <td><?php echo e($admin->email); ?></td>
              <td><?php echo e($admin->created_at); ?></td>
            
		
		        
           
		        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php echo e($admins->links()); ?>

    </div>
   

   
  </div>
  
   </div>
   
   
      </div>

      
              
      
       


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/admin/admin-table.blade.php ENDPATH**/ ?>
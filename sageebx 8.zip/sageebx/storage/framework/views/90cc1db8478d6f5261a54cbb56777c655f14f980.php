<?php $__env->startSection('content'); ?>

<div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    




                    <?php echo $__env->make('customer.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Ship Arrival/Departure</h3>
  	<h1>
  </h1>
   <div class="panel-body1">
    <iframe height='500px' width='100%' frameborder='0' allowTransparency='true' scrolling='auto' src='https://creator.zohopublic.com/sageplatform/ebs/report-embed/FSL_Vessel_Arrival_x2f_Departure/NdgdBk0x81rQWkNKW9CqA0vusDNKGC3gwpNudPUuG4Pje0tRZ0zH1R1C9jVAtAnKpnNnkVV1smV8keR5v0PDP1vjE342V4VzhnqW'></iframe>    
</div>
    
   

   
  </div>
  
   </div>
   
   
      </div>

      
              
      
       


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.customer-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/customer/Ship-Arrival-Departure.blade.php ENDPATH**/ ?>
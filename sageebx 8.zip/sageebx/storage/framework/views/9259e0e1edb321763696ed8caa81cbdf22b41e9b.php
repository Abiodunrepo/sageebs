<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $__env->yieldContent('title_area'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta
      name="keywords"
      content=""
    />
    <style>
      .list-p {
        font-size: 20px;
        color: green;
      }
    </style>
<?php echo $__env->yieldContent('css_js'); ?>

    <style>
      p {
        color: black;
      }
    </style>
    <!----webfonts--->
    <link
      href="https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900"
      rel="stylesheet"
      type="text/css"
    />
    <!---//webfonts--->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('ebs')); ?>js/bootstrap.min.js"></script>
  </head>
  <body>
    <div id="wrapper">
      <!-- Navigation -->
      <?php echo $__env->make('ebs.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div id="page-wrapper">
      <?php echo $__env->make('ebs.inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
      <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- Nav CSS -->
    <link href="<?php echo e(asset('ebs')); ?>/css/custom.css" rel="stylesheet" />
    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('ebs')); ?>/js/metisMenu.min.js"></script>
    <script src="<?php echo e(asset('ebs')); ?>/js/custom.js"></script>
  </body>
</html>
<?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/ebs/master.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    




                    <?php echo $__env->make('admin.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	 <h3>Platform Users</h3>
  	
   <div class="panel-body1">
   <table class="table">
     <thead>
        <tr>
          <th>#</th>
          <th>Full Name</th>
          <th>Company</th>
          <th>Department</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
	  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <tr>
           
		          <th scope="row"><?php echo e($user->id); ?></th>
		          <td><?php echo e($user->fullname); ?></td>
		          <td><?php echo e($user->company); ?></td>
              <td><?php echo e($user->department); ?></td>
              <td><?php echo e($user->email); ?></td>
			  
		        
           
		        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php echo e($users->links()); ?>

    </div>
   

   
  </div>
  
   </div>
   
   
      </div>

      
              
      
       


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/admin/users-table.blade.php ENDPATH**/ ?>
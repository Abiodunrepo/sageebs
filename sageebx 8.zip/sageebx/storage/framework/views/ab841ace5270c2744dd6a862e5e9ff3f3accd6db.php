<?php $__env->startSection('title_area'); ?>
SAGE| EBS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_js'); ?>
<script type="application/x-javascript">
      addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
    </script>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('ebs')); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('ebs')); ?>/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('ebs')); ?>/css/font-awesome.css" rel="stylesheet" />
    <!-- jQuery -->
    <script src="<?php echo e(asset('ebs')); ?>/js/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ebs.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/projectx/sageebx/resources/views/ebs/index.blade.php ENDPATH**/ ?>